using UnityEngine;

public class MouseMovement : MonoBehaviour
{
    public float mouseSensivity = 2f;

    private float xRotation = 0f;
    private float yRotation = 0f;

    private void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    private void Update()
    {
        float xRot = Input.GetAxis("Mouse X") * mouseSensivity * Time.deltaTime;
        float yRot = Input.GetAxis("Mouse Y") * mouseSensivity * Time.deltaTime;

        xRotation -= yRot;
        yRotation += xRot;

        xRotation = Mathf.Clamp(xRotation, -90f, 90f);

        gameObject.transform.localRotation = Quaternion.Euler(xRotation, yRotation, 0f);
    }



}
