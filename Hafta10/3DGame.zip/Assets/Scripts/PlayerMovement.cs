using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public CharacterController controller;
    public Transform sphereTransform;
    public LayerMask sphereMask;

    public bool isGrounded;
    public float sphereRadius = 0.4f;

    private void Update()
    {
        isGrounded = Physics.CheckSphere(sphereTransform.position, sphereRadius, sphereMask);
    }
}
