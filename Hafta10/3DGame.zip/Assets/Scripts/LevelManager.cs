using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour
{    
    public void Level1Load()
    {
        SceneManager.LoadScene(1);
    }    
    public void Quit()
    {
        Application.Quit();
    }
}
